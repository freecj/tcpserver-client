package G8R.app;

import java.net.Socket;
import java.util.logging.Logger;

public class G8RSendGuess extends PollState {

	public G8RSendGuess(Socket clientSocket, Logger logger) {
		super(clientSocket, logger);
		
	}

	@Override
	public void generateMsg() {
		
	}

}
