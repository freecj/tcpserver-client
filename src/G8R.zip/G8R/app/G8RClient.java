package G8R.app;

import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;

import G8R.serialization.*;

public class G8RClient {
	private Socket socket;
	private G8RRequest g8rRequest;
	private G8RResponse g8rResponse;
	private static int firstTime = 0;
	private CookieList cookieClient = null;
	private MessageOutput socketOut = null;
	private MessageInput socketIn = null;
	private String endFlag = "NULL";
	private String cookieFileName;
	private String MessageDelimiter = "\r\n";

	public G8RClient(String ip, int port, String FileName) {
		try {
			// Create socket that is connected to server on specified port
			socket = new Socket(ip, port);
			cookieFileName = FileName;
			// pass the filename or directory name to File object
			File file = new File(cookieFileName);
			if (!file.exists()) {

				file.createNewFile();

				OutputStream cookieFile = new FileOutputStream(file.getAbsoluteFile());

				cookieFile.write(MessageDelimiter.getBytes());
				cookieFile.close();
				cookieClient = new CookieList();
			} else {
				InputStream inCookieFile = new FileInputStream(file.getAbsoluteFile());

				MessageInput inMsg = new MessageInput(inCookieFile);
				cookieClient = new CookieList(inMsg);

			}
			socketOut = new MessageOutput(socket.getOutputStream());
			socketIn = new MessageInput(socket.getInputStream());
			String[] param = new String[0];
			String function = "inital";

			g8rRequest = new G8RRequest(function, param, cookieClient);

		} catch (IOException e) {
			System.err.println("socket init failed:");
			close();
			System.exit(1);
		} catch (ValidationException e) {
			System.err.println("cookieClient init failed:");
			close();
			System.exit(1);
		} finally {

			// System.exit(0);
		}
	}

	public void read() {
		try {
			G8RMessage temp = G8RMessage.decode(socketIn);
			if (temp instanceof G8RResponse) {
				g8rResponse = (G8RResponse) temp;
				System.out.println(g8rResponse.getMessage());

				if (endFlag.equals(g8rResponse.getFunction())) {
					File file = new File(cookieFileName);
					MessageOutput cookieFile = new MessageOutput(new FileOutputStream(file.getAbsoluteFile()));
					g8rResponse.getCookieList().encode(cookieFile);

					close();
					System.exit(0);
				} else {

					g8rRequest.setFunction(g8rResponse.getFunction());
					g8rRequest.setCookieList(g8rResponse.getCookieList());
				}

			} else {
				throw new ValidationException("Message is other", "");
			}
		} catch (ValidationException e) {
			System.err.println("G8RMessage decode failed: ValidationException");
			close();
			System.exit(1);
		} catch (IOException e) {
			System.err.println("G8RMessage decode failed: IOException");
			close();
			System.exit(1);
		}

	}

	public void close() {
		try {
			if (socket != null && !socket.isClosed())
				socket.close();
		} catch (IOException e) {
			System.err.println("socket closed failed:");
		}
	}

	/**
	 * check whether the string valid or not.
	 * 
	 * @param temp
	 *            string to be check
	 * @return if string are alphanumeric, return true. Otherwise false.
	 */
	public boolean isValidParam(String temp) {
		String regex = "^( [A-Za-z0-9]+)+$";// use regex to tesaat whether is alphanumeric or not
		return temp.matches(regex);
	}

	public void sendRequest(String function) {
		try {
			g8rRequest.setFunction(function);
			g8rRequest.encode(socketOut);
		} catch (ValidationException e) {
			System.err.println("socket send Request failed: ValidationException");
			System.exit(1);
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("socket send Request failed: IOException");
			System.exit(1);
		} finally {
			// System.exit(0);
		}
	}

	public void sendRequest(String[] param) {
		try {
			g8rRequest.setFunction(g8rResponse.getFunction());
			g8rRequest.setParams(param);
			g8rRequest.encode(socketOut);
		} catch (ValidationException e) {
			System.err.println("socket send Request failed: ValidationException");
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("socket send Request failed: IOException");
			System.exit(0);
		} finally {
			// System.exit(0);
		}
	}

	public static void main(String[] args) throws IOException {

		if ((args.length < 2) || (args.length > 3)) // Test for correct # of args
			throw new IllegalArgumentException("Parameter(s): <Server> [<Port>] <Cookiefile>");

		String server = args[0]; // Server name or IP address
		// Convert argument String to bytes using the default character encoding
		int servPort = Integer.parseInt(args[1]);
		// accept file name or directory name through command line args
		String cookieFileName = args[2];

		G8RClient client = new G8RClient(server, servPort, cookieFileName);

		System.out.println("please input the function:");

		
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		int index = 0;
		while (true) {
			String userInput = "";
			if ((userInput = stdIn.readLine()) != null) {
				String test = " " + userInput;
				if (!client.isValidParam(test)) {
					System.err.println("input string is wrong. Please input again.");
					continue;
				}
				if (index == firstTime) {
					client.sendRequest(userInput);
				} else {
					System.out.println(userInput);
					String[] param = userInput.split(" ");
					client.sendRequest(param);
				}
				client.read();
				index++;
			}

		}
	}
}
